class StringConst {
  static const String newsTitle = 'News';
  static const String headline = 'HEADLINE';
  static const String errorText = 'Error Loading Articles';
  static const String exceptionText = 'Failed to load news';
  static const String notifications = 'Notifications List';
  static const String notificationDetail = 'Notification Detail';
}
