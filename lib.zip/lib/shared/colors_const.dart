import 'package:flutter/material.dart';

class ColorsConst {
  static const Color redColor = Colors.red;
  static const Color appBarColor = Color(0xff1F0A68);
  static const Color blueColor = Colors.blue;
  static const Color whiteColor = Colors.white;
  static const Color blackColor = Colors.black;
  static const Color black12Color = Colors.black12;
  static const Color black54Color = Colors.black54;
  static const Color black26Color = Colors.black26;
}
