class ApiEndPoint {
  static String newsUrl = 'https://newsapi.org/v2/everything?q=college&apiKey';
}
