import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:intl/intl.dart';
import 'package:myapp/page-1/select_gender_new.dart';
import 'package:myapp/utils.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SelectDobNew extends StatefulWidget {
  const SelectDobNew({super.key});

  @override
  State<SelectDobNew> createState() => _SelectDobNewState();
}

class _SelectDobNewState extends State<SelectDobNew> {
  String date = "DD/MM/YYYY";

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      openDatePicker();
    });
  }

   openDatePicker() async {
    var now = DateTime.now();
    var firstDate = DateTime(1999);
    showDatePicker(
      context: context,
      initialDate: now,
      firstDate: firstDate,
      lastDate: now,
    ).then((value) {
      if (value != null) {
        date = DateFormat("d/M/yyyy").format(value).toString();
        setState(() {});
      }
    });
  }

  @override
  Widget build(BuildContext context) {
   return Scaffold(
     body: Padding(
       padding: const EdgeInsets.only(left: 40,right: 40,top: 100,bottom: 40),
       child: Center(
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           mainAxisAlignment: MainAxisAlignment.center,
           children: [
             const Text('Question 1/3'),
             Image.asset('assets/page-1/images/dob.jpg'),
             const Spacer(),
             Center(
               child: Container(
                 height: 300,
                 decoration: BoxDecoration(
                   border: Border.all(color: Colors.black, width: 2),
                   borderRadius: BorderRadius.circular(8),
                 ),
                 child: Padding(
                   padding: const EdgeInsets.all(48.0),
                   child: Center(
                     child: Column(
                       crossAxisAlignment: CrossAxisAlignment.center,
                       children: [
                         const Text("What's your date of birth?",style: TextStyle(
                         fontSize: 16, fontWeight: FontWeight.bold),),
                         const Spacer(),
                         customButton(
                           onPressed: () {
                             var now = DateTime.now();
                             var firstDate = DateTime(1999);
                             // var lastDate = DateTime(2010);
                             showDatePicker(
                                 context: context,
                                 initialDate: now,
                                 firstDate: firstDate,
                                 lastDate: now)
                                 .then((value) {
                               date = DateFormat("d/M/yyyy").format(value!).toString();
                               setState(() {});
                             });
                           },
                           title: date,
                         ),
                       ],
                     ),
                   ),
                 ),
               ),
             ),
             const Spacer(),
             Padding(
               padding: const EdgeInsets.all(40.0),
               child: Row(
                 mainAxisAlignment: MainAxisAlignment.end,
                 children: [
                   GestureDetector(
                       onTap: ()async{
                         if (date == "DD/MM/YYYY") {
                           EasyLoading.showToast("Please Select the date...",
                               toastPosition: EasyLoadingToastPosition.bottom);
                         } else {
                           var prefs = await SharedPreferences.getInstance();
                           prefs.setString("date", date);

                           if (!mounted) return;
                           Navigator.pushReplacement(
                               context,
                               MaterialPageRoute(
                                   builder: (context) => const SelectGenderNew()));
                         }
                       },
                       child: Image.asset('assets/page-1/images/arrow1.jpg')),
                 ],
               ),
             ),
           ],
         ),
       ),
     ),
   );
  }

  Widget customButton({
    required VoidCallback onPressed,
    required String title,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 22),
      child: SizedBox(
        height: 50,
        width: 200,
        child: OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
              backgroundColor:  Colors.white,
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              )),
          child: Text(
            title,
            style: SafeGoogleFont(
              "Montserrat",
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
    );
  }

  Widget nextButton({required VoidCallback onPressed, required String title}) {
    return SizedBox(
      height: 45,
      width: 326,
      child: OutlinedButton(
          onPressed: onPressed,
          style: OutlinedButton.styleFrom(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              backgroundColor: const Color(0xff1F0A68),
              foregroundColor: Colors.white),
          child: Text(
            title,
            style: SafeGoogleFont(
              "Roboto",
              fontSize: 20,
            ),
          )),
    );
  }
}
